"use strict";
const $ = id => document.getElementById(id);
const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = (n, signed=false) => (signed && n >= 0 ? '+' : '') + Number(n).toLocaleString('en-US', {minimumFractionDigits:2,maximumFractionDigits:2});
const price = (n, digits=2) => n==null?'—':Number(n).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits});
let state, token, tab='positions', view='trade', toastTimer, inFlight=false, stopped=false, connected=true, backtestResult=null;
const changed = new WeakMap();
function htmlIfChanged(element, html) {if(changed.get(element)!==html){element.innerHTML=html;changed.set(element,html);}}
function toast(message, error=false) {clearTimeout(toastTimer);$('toast').textContent=message;$('toast').classList.toggle('error',error);$('toast').hidden=false;toastTimer=setTimeout(()=>{$('toast').hidden=true;},4500);}
async function api(action, data={}) {
  if (!token) throw new Error('กำลังเชื่อมต่อระบบ กรุณารอสักครู่');
  const response=await fetch('/api/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':token},body:JSON.stringify(data)});
  const result=await response.json();
  if(!response.ok) throw new Error(result.error||'ทำรายการไม่สำเร็จ');
  if(action!=='backtest'){state=result;render();}
  return result;
}
async function command(action,data={},message) {try{const result=await api(action,data);if(message)toast(message);return result;}catch(error){toast(error.message,true);return null;}}
function metric(id,value,signed=false){const parts=money(value,signed).split('.');htmlIfChanged($(id),esc(parts[0])+'<span>.'+parts[1]+'</span>');if(id==='unrealized'||id==='net'){$(id).classList.toggle('positive',value>=0);$(id).classList.toggle('negative',value<0);}}
function setTab(name){tab=name;document.querySelectorAll('[data-tab]').forEach(el=>{const active=el.dataset.tab===name;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));});['positions','history','equity','logs'].forEach(t=>{$(t+'-panel').hidden=t!==name;});if(state)render();}
function setView(name){view=name;$('trade-view').hidden=name!=='trade';$('backtest-view').hidden=name!=='backtest';document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===name));$('page-label').textContent=name==='trade'?'เทรด & บอท':'ทดสอบย้อนหลัง';$('page-title').innerHTML=name==='trade'?'พื้นที่เทรดของคุณ<span>.</span>':'ห้องทดลองกลยุทธ์<span>.</span>';$('page-subtitle').textContent=name==='trade'?'ดูตลาด จัดการออเดอร์ และทดลองบอทในที่เดียว':'ทดสอบกับข้อมูลแท่งปิดจริงที่โหลดจาก MT5';redraw();}
function render(){
  if(!state)return;
  const s=state.settings, market=state.market;
  const live=connected&&market.status==='live', tradable=live&&market.currency_profit==='USD';
  metric('balance',state.balance);metric('equity',state.equity);metric('unrealized',state.unrealized,true);metric('net',state.net,true);
  $('equity-change').textContent=((state.equity-5000)/50).toFixed(2)+'%';$('open-count').textContent=state.positions.length+' ออเดอร์';$('win-rate').textContent=state.win_rate===null?'ยังไม่มีรายการ':'Win rate '+state.win_rate+'%';
  $('bot-symbol').textContent=s.symbol+' · '+s.timeframe;$('bot-status').textContent=state.running?'กำลังทำงาน':'หยุดอยู่';$('bot-dot').classList.toggle('running',state.running);$('run-dot').classList.toggle('running',state.running);
  $('run-label').textContent=state.running?state.signal:'บอทพร้อมเริ่มทำงาน';$('signal-label').textContent=state.running?'RUNNING':'STANDBY';$('toggle-bot').textContent=state.running?'Ⅱ หยุดบอทจำลอง':'▶ เริ่มบอทจำลอง';
  if(document.activeElement!==$('lot-input'))$('lot-input').value=s.volume.toFixed(2);
  $('lot-input').disabled=state.running;$('lot-minus').disabled=state.running;$('lot-plus').disabled=state.running;
  $('bid-price').textContent=price(state.bid,state.digits);$('ask-price').textContent=price(state.ask,state.digits);$('chart-symbol').textContent=market.symbol||s.symbol;
  $('chart-description').textContent=(market.server||'Exness MT5')+' · '+s.timeframe+' · UTC';
  $('sl-tp').textContent=s.stop_loss+' / '+s.take_profit;$('max-positions').textContent=s.max_positions;$('free-margin').textContent='$'+money(state.free_margin);$('spread-label').textContent='Spread '+price(state.spread,state.digits);
  $('fast-label').textContent=s.fast;$('slow-label').textContent=s.slow;document.querySelectorAll('[data-frame]').forEach(el=>el.classList.toggle('selected',el.dataset.frame===s.timeframe));
  $('position-tab-count').textContent=state.positions.length;$('positions-empty').hidden=state.positions.length>0;$('history-empty').hidden=state.history.length>0;
  htmlIfChanged($('positions-body'),state.positions.map(p=>`<tr><td>#${p.id} &nbsp; ${esc(p.symbol)}</td><td><span class="side-tag ${p.side}">${p.side.toUpperCase()}</span></td><td>${p.volume.toFixed(2)}</td><td>${price(p.entry,state.digits)}</td><td>${price(p.sl,state.digits)} / ${price(p.tp,state.digits)}</td><td class="${p.pnl>=0?'positive':'negative'}">${money(p.pnl,true)}</td><td><button data-close-order="${p.id}" aria-label="ปิดออเดอร์ ${p.id}">ปิด ×</button></td></tr>`).join(''));
  htmlIfChanged($('history-body'),state.history.map(p=>{const digits=p.digits??2;return `<tr><td>#${p.id}</td><td>${esc(p.symbol)}</td><td><span class="side-tag ${p.side}">${p.side.toUpperCase()}</span></td><td>${price(p.entry,digits)} → ${price(p.exit,digits)}</td><td>${money(p.fee)}</td><td class="${p.net>=0?'positive':'negative'}">${money(p.net,true)}</td><td>${esc(p.reason)}</td></tr>`;}).join(''));
  htmlIfChanged($('logs-list'),state.logs.map(l=>`<div class="log-row"><time>${new Date(l.time).toLocaleTimeString('th-TH',{hour12:false})}</time><span>${esc(l.message)}</span></div>`).join(''));
  const last=state.candles.at(-1);$('ohlc').textContent=last?`O ${price(last.open,state.digits)}  H ${price(last.high,state.digits)}  L ${price(last.low,state.digits)}  C ${price(last.close,state.digits)}`:'ยังไม่มีข้อมูลแท่งเทียนจาก MT5';
  const labels={live:'LIVE · MT5',stale:'ราคาไม่เป็นปัจจุบัน',waiting:'รอข้อมูลแท่งเทียน',disconnected:'MT5 ขาดการเชื่อมต่อ'};
  const status=connected?market.status:'disconnected';
  $('feed-badge').textContent=labels[status];$('feed-badge').classList.toggle('stale',!live);
  $('feed-overlay').hidden=live;$('feed-overlay').classList.toggle('has-bars',state.candles.length>0);
  $('feed-title').textContent=labels[status];
  $('feed-message').textContent=!connected?'แอปขาดการเชื่อมต่อ ข้อมูลบนจอเป็นข้อมูลล่าสุดที่ได้รับ':(market.error||(status==='stale'?'ยังไม่มี tick ใหม่จากโบรกเกอร์ · ตลาดอาจปิดหรือการเชื่อมต่อล่าช้า':'เปิด Exness MT5 ที่ล็อกอินแล้ว จากนั้นกดเชื่อมต่อ'));
  const updated=market.tick_time?new Date(market.tick_time*1000).toLocaleTimeString('en-GB',{timeZone:'UTC'})+' UTC':'—';
  $('feed-status').textContent=labels[status]+' · Tick ล่าสุด '+updated+' · ตรวจทุก 0.5 วินาที';
  $('buy-button').disabled=!tradable||inFlight;$('sell-button').disabled=!tradable||inFlight;
  $('toggle-bot').disabled=!state.running&&(!tradable||state.candles.length<s.slow+2);
  $('close-all').disabled=!tradable&&!state.running;$('run-backtest').disabled=!connected||!state.mt5.connected;
  document.querySelectorAll('[data-close-order]').forEach(el=>el.disabled=!tradable);
  if(!live){$('run-label').textContent='รอราคาปัจจุบันจาก MT5';$('signal-label').textContent='WAITING';}
  if(state.positions.length&&!live)$('equity-change').textContent='มูลค่าจากราคาล่าสุดที่ได้รับ';
  renderMT5();redraw();
  if(state.error)$('server-status').textContent=state.error;
}
function renderMT5(){const m=state.mt5;$('connection-label').textContent=m.connected?(state.market.status==='live'?'LIVE · ราคาจริง':'เชื่อมแล้ว · รอราคาใหม่'):(m.error?'ขาดการเชื่อมต่อ':'ยังไม่ได้เชื่อมต่อ');$('mt5-account').hidden=!m.connected;if(!m.connected){if(m.error&&$('connect-dialog').open)$('connect-error').textContent=m.error;return;}
  htmlIfChanged($('mt5-details'),`<strong>${esc(m.server)} · ${esc(m.account)}</strong> <span class="badge mini">${m.demo?'DEMO':'REAL'} · READ ONLY</span><br>Balance ${money(m.balance)} ${esc(m.currency)} &nbsp; Equity ${money(m.equity)}<br><strong>${esc(m.symbol)}</strong> &nbsp; Bid ${price(m.bid,m.digits)} / Ask ${price(m.ask,m.digits)}`);
  const age=Math.max(0,Math.floor(Date.now()/1000-m.tick_time));$('mt5-tick-time').textContent=age>15?`ราคาเก่า ${Math.floor(age/60)} นาที`:'อัปเดต '+new Date(m.tick_time*1000).toLocaleTimeString('th-TH',{hour12:false});
  if($('connect-dialog').open)drawCandles($('mt5-chart'),m.candles,m.digits,false);
}
function canvasContext(canvas){const rect=canvas.getBoundingClientRect();if(rect.width<1||rect.height<1)return null;const ratio=window.devicePixelRatio||1;canvas.width=Math.round(rect.width*ratio);canvas.height=Math.round(rect.height*ratio);const ctx=canvas.getContext('2d');ctx.scale(ratio,ratio);ctx.font='10px "Segoe UI", sans-serif';return {ctx,w:rect.width,h:rect.height};}
function ema(values,period){let previous=values[0];return values.map((v,i)=>{if(i)previous=v*2/(period+1)+previous*(1-2/(period+1));return previous;});}
function drawCandles(canvas,all,digits=2,indicators=true){const surface=canvasContext(canvas);if(!surface||!all.length){canvas._bars=null;return;}const {ctx,w,h}=surface;const currentBid=canvas.id==='price-chart'?state?.bid:null;const bars=all.slice(-Math.max(35,Math.floor((w-82)/7)));const padding={left:16,right:76,top:20,bottom:35};const cw=w-padding.left-padding.right,ch=h-padding.top-padding.bottom;let min=Math.min(...bars.map(b=>b.low)),max=Math.max(...bars.map(b=>b.high));if(currentBid!=null){min=Math.min(min,currentBid);max=Math.max(max,currentBid);}const extra=Math.max((max-min)*.12,.00001);min-=extra;max+=extra;const y=n=>padding.top+(max-n)/(max-min)*ch;const step=cw/bars.length;const x=i=>padding.left+(i+.5)*step;
  ctx.strokeStyle='#20303a';ctx.lineWidth=.6;ctx.fillStyle='#637f90';ctx.textAlign='left';for(let i=0;i<=5;i++){const py=padding.top+i*ch/5;ctx.beginPath();ctx.moveTo(padding.left,py);ctx.lineTo(w-padding.right+7,py);ctx.stroke();ctx.fillText(price(max-i*(max-min)/5,digits),w-padding.right+13,py+3);}
  const times=Math.min(6,Math.floor(cw/80));ctx.textAlign='center';for(let i=0;i<=times;i++){const index=Math.min(bars.length-1,Math.floor(i*bars.length/times));const px=x(index);ctx.strokeStyle='#1b2a33';ctx.beginPath();ctx.moveTo(px,padding.top);ctx.lineTo(px,h-padding.bottom);ctx.stroke();ctx.fillStyle='#5a7687';ctx.fillText(new Date(bars[index].time*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'}),px,h-11);}
  const volMax=Math.max(...bars.map(b=>b.volume),1);bars.forEach((b,i)=>{const color=b.close>=b.open?'#38c69c':'#e47b78';ctx.globalAlpha=.13;ctx.fillStyle=color;const vh=b.volume/volMax*ch*.16;ctx.fillRect(x(i)-step*.32,h-padding.bottom-vh,Math.max(1,step*.64),vh);ctx.globalAlpha=1;ctx.strokeStyle=color;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x(i),y(b.high));ctx.lineTo(x(i),y(b.low));ctx.stroke();ctx.fillStyle=color;ctx.fillRect(x(i)-step*.32,Math.min(y(b.open),y(b.close)),Math.max(1,step*.64),Math.max(1.2,Math.abs(y(b.open)-y(b.close))));});
  if(indicators&&state){[[state.settings.fast,'#c5ab70'],[state.settings.slow,'#6f8cb5']].forEach(([period,color])=>{const line=ema(all.map(b=>b.close),period).slice(-bars.length);ctx.strokeStyle=color;ctx.globalAlpha=.8;ctx.lineWidth=1.1;ctx.beginPath();line.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v)));ctx.stroke();ctx.globalAlpha=1;});}
  const last=bars.at(-1);const marker=currentBid??last.close;const py=y(marker);ctx.strokeStyle='#36dca78a';ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(padding.left,py);ctx.lineTo(w-padding.right+9,py);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#2f9e7c';ctx.fillRect(w-padding.right+7,py-9,padding.right-10,18);ctx.fillStyle='#e1fff2';ctx.textAlign='center';ctx.fillText(price(marker,digits),w-padding.right/2+2,py+3);canvas._bars={bars,left:padding.left,step,cw};
}
function drawEquity(canvas,points){const surface=canvasContext(canvas);if(!surface||!points.length)return;const {ctx,w,h}=surface;const left=14,right=75,top=22,bottom=24;const values=points.map(p=>p.value);let low=Math.min(...values,5000),high=Math.max(...values,5000);const extra=Math.max((high-low)*.2,5);low-=extra;high+=extra;const y=v=>top+(high-v)/(high-low)*(h-top-bottom);const x=i=>left+i/Math.max(points.length-1,1)*(w-left-right);ctx.textAlign='left';ctx.fillStyle='#617d8e';for(let i=0;i<4;i++){const v=low+i*(high-low)/3;ctx.strokeStyle='#22323b';ctx.beginPath();ctx.moveTo(left,y(v));ctx.lineTo(w-right,y(v));ctx.stroke();ctx.fillText(money(v),w-right+12,y(v)+3);}const gradient=ctx.createLinearGradient(0,top,0,h-bottom);gradient.addColorStop(0,'#36dca72c');gradient.addColorStop(1,'#36dca700');ctx.beginPath();ctx.moveTo(x(0),h-bottom);points.forEach((p,i)=>ctx.lineTo(x(i),y(p.value)));ctx.lineTo(x(points.length-1),h-bottom);ctx.closePath();ctx.fillStyle=gradient;ctx.fill();ctx.strokeStyle='#42d9a9';ctx.lineWidth=1.8;ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(x(i),y(p.value)):ctx.moveTo(x(i),y(p.value)));ctx.stroke();if(points.length===1){ctx.beginPath();ctx.arc(x(0),y(points[0].value),3,0,Math.PI*2);ctx.fillStyle='#42d9a9';ctx.fill();}}
function redraw(){if(!state)return;if(view==='trade'){drawCandles($('price-chart'),state.candles,state.digits);if(tab==='equity')drawEquity($('equity-chart'),state.equity_curve);}if(view==='backtest'&&backtestResult)drawEquity($('backtest-chart'),backtestResult.equity_curve);}
function confirmAction(title,message,callback){$('confirm-title').textContent=title;$('confirm-message').textContent=message;$('confirm-dialog').showModal();$('confirm-ok').onclick=()=>{$('confirm-dialog').close();callback();};}
document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.view)));
document.querySelectorAll('[data-tab]').forEach(el=>el.addEventListener('click',()=>setTab(el.dataset.tab)));
document.querySelectorAll('[data-close]').forEach(el=>el.addEventListener('click',()=>$(el.dataset.close).close()));
$('confirm-cancel').onclick=()=>$('confirm-dialog').close();
$('nav-history').onclick=()=>{setView('trade');setTab('history');$('history-panel').scrollIntoView({behavior:'smooth',block:'center'});};
$('toggle-bot').onclick=async()=>{if(inFlight||!state)return;inFlight=true;try{await command(state.running?'stop':'start');}finally{inFlight=false;}};
async function saveLot(){if(!state)return false;const value=Number($('lot-input').value);if(value===state.settings.volume)return true;return !!await command('settings',{volume:value});}
async function order(side){if(inFlight||!state)return;inFlight=true;try{if(await saveLot())await command('order',{side},'เปิดออเดอร์ '+side.toUpperCase()+' จำลองแล้ว');}finally{inFlight=false;}}
$('buy-button').onclick=()=>order('buy');$('sell-button').onclick=()=>order('sell');
$('lot-minus').onclick=()=>{if(state)$('lot-input').value=Math.max(.01,Number($('lot-input').value)-.01).toFixed(2);};
$('lot-plus').onclick=()=>{if(state)$('lot-input').value=Math.min(5,Number($('lot-input').value)+.01).toFixed(2);};
$('lot-input').onchange=saveLot;
for(const id of ['lot-minus','lot-plus'])$(id).addEventListener('click',saveLot);
$('positions-body').onclick=e=>{const button=e.target.closest('[data-close-order]');if(button){button.disabled=true;command('close',{id:Number(button.dataset.closeOrder)},'ปิดออเดอร์จำลองแล้ว').finally(()=>button.disabled=false);}};
$('close-all').onclick=()=>confirmAction('หยุดบอท & ปิดทั้งหมด','ปิดออเดอร์จำลองที่เปิดอยู่ทั้งหมดด้วยราคาปัจจุบัน และหยุดบอท',()=>command('close_all',{},'หยุดบอทและปิดออเดอร์จำลองทั้งหมดแล้ว'));
document.querySelectorAll('[data-frame]').forEach(el=>el.onclick=()=>command('settings',{timeframe:el.dataset.frame}));
$('settings-button').onclick=()=>{if(!state)return;for(const [name,value]of Object.entries(state.settings)){const input=$('settings-form').elements.namedItem(name);if(input)input.value=value;}$('settings-error').textContent='';$('settings-dialog').showModal();};
$('settings-form').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries([...new FormData(e.currentTarget)].map(([k,v])=>[k,Number(v)]));try{await api('settings',data);$('settings-dialog').close();toast('บันทึกการตั้งค่าแล้ว');}catch(error){$('settings-error').textContent=error.message;}};
$('reset-account').onclick=()=>confirmAction('เริ่มบัญชีจำลองรอบใหม่','ยอดเงินจะกลับเป็น $5,000 ประวัติรอบเดิมจะเก็บเป็น CSV บนเครื่อง ต้องหยุดบอทและปิดออเดอร์ก่อน',async()=>{if(await command('reset',{},'เริ่มบัญชีจำลองรอบใหม่แล้ว'))$('settings-dialog').close();});
$('expand-chart').onclick=()=>{document.querySelector('.chart-panel').classList.toggle('expanded');redraw();};
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelector('.chart-panel').classList.remove('expanded');redraw();}});
$('price-chart').addEventListener('mousemove',e=>{const data=e.target._bars;if(!data)return;const i=Math.floor((e.offsetX-data.left)/data.step);if(i<0||i>=data.bars.length){$('chart-tooltip').hidden=true;return;}const c=data.bars[i];$('chart-tooltip').textContent=new Date(c.time*1000).toLocaleString('th-TH')+' · O '+price(c.open,state.digits)+' / H '+price(c.high,state.digits)+' / L '+price(c.low,state.digits)+' / C '+price(c.close,state.digits);$('chart-tooltip').hidden=false;});
$('price-chart').onmouseleave=()=>{$('chart-tooltip').hidden=true;};
$('run-backtest').onclick=async()=>{const button=$('run-backtest');button.disabled=true;button.textContent='กำลังทดสอบ…';try{const r=await api('backtest');backtestResult=r;$('backtest-results').hidden=false;htmlIfChanged($('backtest-metrics'),`<div><span>กำไรสุทธิจำลอง</span><strong class="${r.net>=0?'positive':'negative'}">${money(r.net,true)}</strong></div><div><span>รายการที่ปิดแล้ว</span><strong>${r.trades}</strong></div><div><span>Win rate</span><strong>${r.win_rate??0}%</strong></div><div><span>Max drawdown</span><strong>${r.drawdown}%</strong></div>`);$('backtest-note').textContent=r.note+' · '+r.settings.symbol+' / '+r.settings.timeframe+' · EMA '+r.settings.fast+'/'+r.settings.slow;redraw();}catch(error){toast(error.message,true);}finally{button.disabled=false;button.textContent='↻ ทดสอบข้อมูล MT5 อีกครั้ง';}};
const openConnect=()=>{$('connect-error').textContent='';$('connect-dialog').showModal();if(state)renderMT5();};
for(const id of ['open-connect','chart-connect','change-symbol'])$(id).onclick=openConnect;
$('connect-form').onsubmit=async e=>{e.preventDefault();const button=$('connect-submit');button.disabled=true;button.textContent='กำลังเชื่อมต่อ…';$('connect-error').textContent='';try{const result=await api('connect',Object.fromEntries(new FormData(e.currentTarget)));if(!result.mt5.connected){$('connect-error').textContent=result.mt5.error||'รอการเชื่อมต่อ MT5';return;}toast('กราฟหลักเชื่อมกับ MT5 แล้ว');$('connect-dialog').close();}catch(error){$('connect-error').textContent=error.message;}finally{button.disabled=false;button.textContent='เชื่อมต่อ MT5 ↗';}};
$('disconnect-mt5').onclick=()=>command('disconnect',{},'ตัดการเชื่อมต่อ MT5 แล้ว');
for(const id of ['help-button','notice-help'])$(id).onclick=()=>$('help-dialog').showModal();
$('exit-button').onclick=()=>confirmAction('ออกจากโปรแกรม','ระบบจะหยุดบอทและเก็บ CSV พร้อมออเดอร์ paper ที่ยังไม่ปิด การเปิดใหม่เริ่มรอบบัญชีใหม่',async()=>{if(await command('shutdown')){stopped=true;$('server-status').textContent='ปิดโปรแกรมแล้ว';document.body.classList.add('offline');document.querySelectorAll('button,select,input').forEach(b=>b.disabled=true);toast('ปิดโปรแกรมแล้ว สามารถปิดหน้าต่างนี้ได้');}});
window.addEventListener('resize',()=>{redraw();if(state)renderMT5();});
setInterval(()=>{$('clock').textContent=new Date().toLocaleTimeString('en-GB')+' LOCAL';},1000);
async function poll(){if(stopped)return;try{if(!token){const bootstrap=await fetch('/api/bootstrap',{signal:AbortSignal.timeout(3000)});if(!bootstrap.ok)throw new Error();token=(await bootstrap.json()).token;}const response=await fetch('/api/state',{signal:AbortSignal.timeout(3000)});if(!response.ok)throw new Error();state=await response.json();connected=true;document.body.classList.remove('offline');$('server-status').textContent='ระบบพร้อมใช้งาน';render();}catch{connected=false;document.body.classList.add('offline');$('server-status').textContent='ขาดการเชื่อมต่อ · กำลังลองใหม่';if(state)render();}finally{if(!stopped)setTimeout(poll,500);}}
poll();
