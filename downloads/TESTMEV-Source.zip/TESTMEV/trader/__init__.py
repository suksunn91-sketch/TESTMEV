"""TESTMEV desktop trading workspace."""
